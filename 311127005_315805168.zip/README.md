# Project_PartA

Maze generation and search project

Maze generation according to pseudo code writen in: https://stackoverflow.com/questions/29739751/implementing-a-randomly-generated-maze-using-prims-algorithm

Search algorithms according to pseudo code writen in: https://courses.cs.washington.edu/courses/cse326/09sp/projects/proj2/t2.html

